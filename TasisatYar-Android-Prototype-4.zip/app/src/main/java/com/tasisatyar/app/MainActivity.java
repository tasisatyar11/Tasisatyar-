package com.tasisatyar.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout box;
    String[] services={"لوله‌کشی","پکیج و آبگرمکن","کولر و تهویه","فاضلاب","تأسیسات ساختمان","سایر خدمات"};

    public void onCreate(Bundle b){
        super.onCreate(b); showHome();
    }
    TextView title(String s){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(25); t.setTextColor(Color.DKGRAY);
        t.setGravity(Gravity.CENTER); t.setPadding(12,30,12,20); return t;
    }
    Button btn(String s){
        Button x=new Button(this); x.setText(s); x.setTextSize(17); x.setAllCaps(false);
        x.setOnClickListener(v -> showRequest(s)); return x;
    }
    void base(){
        ScrollView sc=new ScrollView(this); box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(25,10,25,25); sc.addView(box); setContentView(sc);
    }
    void showHome(){
        base(); box.addView(title("🔧 تأسیسات‌یار"));
        TextView sub=new TextView(this); sub.setText("درخواست خدمات تأسیساتی در چند مرحله"); sub.setTextSize(16); sub.setGravity(Gravity.CENTER); box.addView(sub);
        box.addView(title("انتخاب خدمت"));
        for(String s:services) box.addView(btn(s));
        Button tech=new Button(this); tech.setText("🧰 ورود تأسیسات‌کار"); tech.setAllCaps(false);
        tech.setOnClickListener(v -> showTechnician()); box.addView(tech);
    }
    void showRequest(String service){
        base(); box.addView(title("ثبت درخواست"));
        TextView t=new TextView(this); t.setText("خدمت انتخاب‌شده: "+service); t.setTextSize(18); box.addView(t);
        EditText desc=new EditText(this); desc.setHint("توضیح مشکل را بنویسید"); desc.setMinLines(4); box.addView(desc);
        EditText addr=new EditText(this); addr.setHint("آدرس"); box.addView(addr);
        EditText phone=new EditText(this); phone.setHint("شماره تماس"); phone.setInputType(3); box.addView(phone);
        Button send=new Button(this); send.setText("ثبت درخواست"); send.setAllCaps(false);
        send.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("درخواست ثبت شد").setMessage("درخواست شما برای خدمت «"+service+"» ثبت شد.").setPositiveButton("باشه",(d,w)->showHome()).show());
        box.addView(send);
        Button back=new Button(this); back.setText("بازگشت"); back.setAllCaps(false); back.setOnClickListener(v->showHome()); box.addView(back);
    }
    void showTechnician(){
        base(); box.addView(title("🧰 پنل تأسیسات‌کار"));
        TextView t=new TextView(this); t.setText("سفارش‌های جدید\n\n📍 تعمیر لوله آب — نزدیک شما\n💧 رفع نشتی — امروز\n❄️ سرویس کولر — امروز"); t.setTextSize(18); t.setPadding(10,10,10,20); box.addView(t);
        Button p=new Button(this); p.setText("پروفایل و مهارت‌ها"); p.setAllCaps(false); p.setOnClickListener(v->profile()); box.addView(p);
        Button back=new Button(this); back.setText("بازگشت"); back.setAllCaps(false); back.setOnClickListener(v->showHome()); box.addView(back);
    }
    void profile(){
        base(); box.addView(title("پروفایل تأسیسات‌کار"));
        EditText name=new EditText(this); name.setHint("نام و نام خانوادگی"); box.addView(name);
        EditText skills=new EditText(this); skills.setHint("مهارت‌ها: لوله‌کشی، پکیج، کولر..."); box.addView(skills);
        Button save=new Button(this); save.setText("ذخیره پروفایل"); save.setAllCaps(false); save.setOnClickListener(v->Toast.makeText(this,"پروفایل ذخیره شد",Toast.LENGTH_SHORT).show()); box.addView(save);
        Button back=new Button(this); back.setText("بازگشت"); back.setAllCaps(false); back.setOnClickListener(v->showTechnician()); box.addView(back);
    }
}
